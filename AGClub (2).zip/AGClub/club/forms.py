from django import forms

class WithdrawForm(forms.Form):
    upi_id = forms.CharField(max_length=100, required=True, help_text="Enter your UPI ID (e.g., example@upi)")
    amount = forms.DecimalField(decimal_places=2, max_digits=10, required=True, help_text="Enter the amount to withdraw")
