from django.test import TestCase
from django.conf import settings
from twilio.rest import Client

TWILIO_ACCOUNT_SID = 'AC8dd1760882bf2aacaea695b95de2a6b0'
TWILIO_AUTH_TOKEN = '90f8848a4e265d92c816d665191816ff'
TWILIO_PHONE_NUMBER = '+16369238247'

def send_test_sms():
    """
    Sends a test SMS using Twilio to verify the setup.
    """
    try:
        # Ensure you have the correct configuration values
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        
        message = client.messages.create(
            body="This is a test message from Twilio.",
            from_=settings.TWILIO_PHONE_NUMBER,
            to='+919631493452'  # Use a verified number if needed
        )
        print(f"Message SID: {message.sid}")
        return "Test message sent successfully."
    except Exception as e:
        print(f"Error sending test message: {str(e)}")
        if hasattr(e, 'code'):
            print(f"Twilio Error Code: {e.code}")
        if hasattr(e, 'more_info'):
            print(f"More info: {e.more_info}")
        return f"Error: {str(e)}"
