from django.urls import path
from club.views import *

urlpatterns = [
    path('', home, name='home'),
    path('product/', product, name="product"),
    path('team/', team, name="team"),
    path('official/', official, name="official"),
    path('profile/', profile, name="profile"),
    path('login/', login_view, name="login"),
    path('register', register_view, name="register"),
    # path('send_otp', send_otp, name="send_otp"),
    # path('verify_otp', verify_otp, name="verify_otp"),
    path('recharge/', recharge, name='recharge_no_params'),
    path('recharge/<str:random_name>/<str:fake_upi_id>/', recharge, name='recharge'),
    path('withdraw/', withdraw, name='withdraw'),
]
