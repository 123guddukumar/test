import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyAqAj2DFr5H1RXCusljY70gyCocimCp5WA",
    "authDomain": "agclub-a3078.firebaseapp.com",
    "projectId": "agclub-a3078",
    "storageBucket": "agclub-a3078.appspot.com",
    "messagingSenderId": "122469670685",
    "appId": "1:122469670685:web:06f3ca765bfc9cf8a8cbf4",
    "measurementId": "G-H1DE136LZX",
    "databaseURL": "https://agclub-a3078-default-rtdb.firebaseio.com/"  # Add the database URL here
}

firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()

def send_otp(phone_number):
    """
    Send OTP using Firebase Authentication.

    Args:
    - phone_number: The recipient's phone number in E.164 format.

    Returns:
    - str: Success message or error message.
    """
    try:
        # Trigger OTP using Firebase phone auth
        auth.send_verification_code(phone_number)
        send_otp(phone_number)
        return "OTP sent successfully."
    except Exception as e:
        print(f"Error sending OTP: {str(e)}")
        return f"Error: {str(e)}"
