from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from twilio.rest import Client
import json, random
from django.core.exceptions import ValidationError
import re
import requests
from django.conf import settings
from django.http import JsonResponse
from .models import CustomUser
from .utils import send_otp

import qrcode
import base64
from io import BytesIO
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse

from django.contrib import messages
from .forms import WithdrawForm


# Create your views here.
def home(request):
    if request.user.is_authenticated:
        return render(request, 'index.html')
    return redirect('login')


@login_required
def recharge(request, random_name=None, fake_upi_id=None):
    real_upi_id = "8084661813@okbizaxis"  # Your real UPI ID for payment
    payee_name = "FDShop"
    transaction_id = "012345678901234"
    transaction_ref = "1234567890"
    transaction_note = "Payment for Club"
    amount = "1.00"  # This can be dynamically set

    # Generate new random name and fake UPI ID if parameters are not provided
    if not random_name or not fake_upi_id:
        random_name = random.choice(["John Doe", "Jane Smith", "Alpha Corp", "Beta Ltd.", "Gamma Services"])
        fake_upi_id = 'fake' + str(random.randint(100000000000, 999999999999))
    
    # Ensure the passed name is valid
    valid_names = ["John Doe", "Jane Smith", "Alpha Corp", "Beta Ltd.", "Gamma Services"]
    if random_name not in valid_names:
        random_name = random.choice(valid_names)

    # Generate a new random number for the QR code
    random_suffix = random.randint(1000, 9999)

    # Generate the QR code data
    qr_data = (
        f"upi://pay?pa={real_upi_id}&pn={payee_name}&tid={transaction_id}&tr={transaction_ref}"
        f"&tn={transaction_note}&am={amount}&cu=INR&rand={random_suffix}"
    )

    # Generate the QR code
    qr_img = qrcode.make(qr_data)
    
    # Save the QR code to a BytesIO object
    qr_buffer = BytesIO()
    qr_img.save(qr_buffer)
    qr_buffer.seek(0)
    
    # Convert the QR code to a base64 string for rendering in the template
    qr_base64 = base64.b64encode(qr_buffer.getvalue()).decode('utf-8')
    
    # Context with the QR code image and the randomized display name
    context = {
        'qr_image': qr_base64,
        'random_name': random_name,
        'fake_upi_id': fake_upi_id
    }
    
    return render(request, 'payment/recharge.html', context)


def withdraw(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = WithdrawForm(request.POST)
            if form.is_valid():
                upi_id = form.cleaned_data['upi_id']
                amount = form.cleaned_data['amount']

                # Validate UPI ID format (basic validation)
                if '@' not in upi_id:
                    messages.error(request, "Invalid UPI ID format.")
                    return render(request, 'withdraw.html', {'form': form})

                # Process withdrawal (e.g., save to database, send notification, etc.)
                # Implement your logic here, e.g., save withdrawal request to the database

                # For demonstration, let's just show a success message
                messages.success(request, f"Withdrawal of {amount} to {upi_id} was successful!")
                return redirect('home')  # Redirect to the home page or wherever you want

        else:
            form = WithdrawForm()
        
        return render(request, 'payment/withdraw.html', {'form': form})
    
    return redirect('login')


def product(request):
    if request.user.is_authenticated:
        return render(request, 'product/product_source/product.html')
    return redirect('login')

def team(request):
    if request.user.is_authenticated:
        return render(request, 'team/team_source/team.html')
    return redirect('login')

def official(request):
    if request.user.is_authenticated:
        return render(request, 'official/official_source/official.html')
    return redirect('login')

def profile(request):
    if request.user.is_authenticated:
        user = request.user
        context = {
            'phone_number': user.phone_number,
            'unique_id': user.unique_id  # This should now show a valid unique ID
        }
        return render(request, "profile/profile_source/user.html", context)
    return redirect('login')

# Twilio Credentials (replace with your own)
import random
from twilio.rest import Client
from django.shortcuts import render, redirect
from .models import CustomUser  # Assuming you have a CustomUser model

# Twilio credentials
import random
from twilio.rest import Client
from django.shortcuts import render, redirect
from .models import CustomUser  # Ensure this import matches your project structure


import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyAqAj2DFr5H1RXCusljY70gyCocimCp5WA",
    "authDomain": "agclub-a3078.firebaseapp.com",
    "projectId": "agclub-a3078",
    "storageBucket": "agclub-a3078.appspot.com",
    "messagingSenderId": "122469670685",
    "appId": "1:122469670685:web:06f3ca765bfc9cf8a8cbf4",
    "measurementId": "G-H1DE136LZX",
    "databaseURL": "https://agclub-a3078-default-rtdb.firebaseio.com/"  # Add the database URL here
}

firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()

def send_otp(phone_number):
    """
    Send OTP using Firebase Authentication.

    Args:
    - phone_number: The recipient's phone number in E.164 format.

    Returns:
    - str: Success message or error message.
    """
    try:
        # Trigger OTP using Firebase phone auth
        auth.send_verification_code(phone_number)
        send_otp(phone_number)
        return "OTP sent successfully."
    except Exception as e:
        print(f"Error sending OTP: {str(e)}")
        return f"Error: {str(e)}"


def register_view(request):
    otp_sent = request.session.get('otp_sent', False)
    otp_verified = request.session.get('otp_verified', False)
    message = None

    if request.method == 'POST':
        action = request.POST.get('action')
        phone_number = request.POST.get('phone_number')
        otp_input = request.POST.get('otp')

        if action == 'Send OTP' and phone_number:
            # Check if phone number already exists
            if CustomUser.objects.filter(phone_number=phone_number).exists():
                message = 'This phone number is already registered. Please log in.'
                return render(request, 'Authentication/register.html', {'otp_sent': False, 'message': message})

            # Send OTP via Firebase
            response = send_otp(phone_number)
            print(f"send_otp response: {response}")

            if 'Error' in response:
                message = 'Failed to send OTP. Check if the number is correct or try again.'
                otp_sent = False
            else:
                request.session['otp_sent'] = True
                request.session['phone_number'] = phone_number
                message = 'OTP sent successfully.'

            return render(request, 'Authentication/register.html', {'otp_sent': True, 'message': message})

        elif action == 'Verify OTP':
            # OTP verification logic (you may need to customize this based on Firebase's OTP verification response)
            if otp_input == request.session.get('otp'):
                request.session['otp_verified'] = True
                otp_verified = True
                message = 'OTP verified successfully. Please enter your password.'
            else:
                message = 'Invalid OTP. Please try again.'
            return render(request, 'Authentication/register.html', {'otp_sent': True, 'otp_verified': otp_verified, 'message': message})

        elif action == 'Register' and otp_verified:
            password = request.POST.get('password')

            if password:
                phone_number = request.session.get('phone_number')
                # Save user to the database
                CustomUser.objects.create_user(phone_number=phone_number, password=password)
                message = 'Registration successful.'
                return redirect('login')
            else:
                message = 'Please provide a password.'
    
    return render(request, 'Authentication/register.html', {'otp_sent': otp_sent, 'otp_verified': otp_verified, 'message': message})



def login_view(request):
    message = None
    if request.method == 'POST':
        print(request.POST)  # Print the entire POST data
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')

        print(f'Phone Number: {phone_number}, Password: {password}')
        user = authenticate(request, phone_number=phone_number, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirect to home page or any desired page
        else:
            message = 'Invalid phone number or password.'

    return render(request, 'Authentication/login.html', {'message': message})


# def register_view(request):
#     otp_sent = request.session.get('otp_sent', False)
#     otp_verified = request.session.get('otp_verified', False)
#     message = None

#     if request.method == 'POST':
#         action = request.POST.get('action')
#         phone_number = request.POST.get('phone_number')
#         otp_input = request.POST.get('otp')

#         # Send OTP logic
#         if action == 'Send OTP' and phone_number:
#             otp = str(random.randint(1000, 9999))  # Generate OTP
#             request.session['otp'] = otp
#             request.session['phone_number'] = phone_number
#             response = send_otp(phone_number, otp)

#             if 'Error' in response:
#                 message = 'Failed to send OTP. Check if the number is verified or upgrade your account.'
#                 otp_sent = False
#             else:
#                 request.session['otp_sent'] = True
#                 message = 'OTP sent successfully.'
#             return render(request, 'Authentication/register.html', {'otp_sent': True, 'message': message})

#         # Verify OTP logic
#         elif action == 'Verify OTP':
#             if otp_input == request.session.get('otp'):
#                 request.session['otp_verified'] = True
#                 otp_verified = True
#                 message = 'OTP verified successfully. Please enter your password.'
#             else:
#                 message = 'Invalid OTP. Please try again.'
#             return render(request, 'Authentication/register.html', {'otp_sent': True, 'otp_verified': otp_verified, 'message': message})

#         # Register logic after OTP verification
#         elif action == 'Register' and otp_verified:
#             password = request.POST.get('password')

#             # Create user logic (assuming you have a custom user model)
#             if password:
#                 phone_number = request.session.get('phone_number')
#                 # Save user to the database
#                 # CustomUser.objects.create_user(phone_number=phone_number, password=password)
#                 message = 'Registration successful.'
#                 # Redirect to home or login
#                 return redirect('login')
#             else:
#                 message = 'Please provide a password.'
    
#     return render(request, 'Authentication/register.html', {'otp_sent': otp_sent, 'otp_verified': otp_verified, 'message': message})



# def login_view(request):
#     message = None
#     if request.method == 'POST':
#         phone_number = request.POST.get('phone_number')
#         password = request.POST.get('password')

#         # Authenticate user
#         user = authenticate(phone_number=phone_number, password=password)
#         if user:
#             login(request, user)
#             return redirect('home')  # Redirect to home page or any desired page
#         else:
#             message = 'Invalid phone number or password.'

#     return render(request, 'Authentication/login.html', {'message': message})


def logout_view(request):
    logout(request)
    return redirect('login')

# @csrf_exempt
# def send_otp(request):
#     if request.method == 'POST':
#         data = json.loads(request.body)
#         mobile = data.get('mobile')

#         if mobile:
#             otp = random.randint(100000, 999999)

#             try:
#                 client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
#                 message = client.messages.create(
#                     body=f"Your OTP code is {otp}",
#                     from_=TWILIO_PHONE_NUMBER,
#                     to=f"+91{mobile}"
#                 )
#                 otp_storage[mobile] = otp
#                 return JsonResponse({'success': True, 'message': 'OTP sent successfully'})
#             except Exception as e:
#                 return JsonResponse({'success': False, 'message': str(e)})
#         else:
#             return JsonResponse({'success': False, 'message': 'Mobile number is required'})

#     return JsonResponse({'success': False, 'message': 'Invalid request method'})


# @csrf_exempt
# def verify_otp(request):
#     if request.method == 'POST':
#         data = json.loads(request.body)
#         mobile = data.get('mobile')
#         otp = data.get('otp')

#         if mobile and otp_storage.get(mobile) == int(otp):
#             del otp_storage[mobile]
#             return JsonResponse({'success': True, 'message': 'OTP verified successfully'})
#         else:
#             return JsonResponse({'success': False, 'message': 'Invalid OTP'})

#     return JsonResponse({'success': False, 'message': 'Invalid request method'})
